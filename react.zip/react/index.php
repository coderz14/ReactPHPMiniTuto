



<?php

require 'vendor/autoload.php';

use React\EventLoop\Factory;
use React\Promise\Promise;

$loop = Factory::create();

// Tableau de valeurs à lire simultanément
$values = glob('files/*.txt');

// Fonction pour simuler une tâche avec un délai aléatoire
$asyncTask = function ($value, $index) use ($loop) {
    $start = microtime(true);
    $delay = mt_rand(1000000, 5000000); // Délai aléatoire entre 1 et 5 secondes en microsecondes
    return new Promise(function ($resolve, $reject) use ($value, $index, $delay, $start, $loop) {
        $loop->addTimer($delay / 1000000, function () use ($value, $index, $resolve, $start) {
            $executionTime = microtime(true) - $start; // Temps écoulé en secondes
            $formattedTime = date('H:i:s', $start) . '.' . substr(str_replace('0.', '', microtime()), 2, 3); // Heure de début formatée avec millisecondes
                 $resolve("<h1>".$value."</h1>".file_get_contents($value)."<b>Temps de lecture (".$formattedTime."</b>\n <hr>");
        });
    });
};

// Créer simultanément toutes les promesses
$promises = array_map(function ($value, $index) use ($asyncTask) {
    return $asyncTask($value, $index);
}, $values, array_keys($values));

// Exécuter toutes les promesses simultanément
\React\Promise\all($promises)->then(function ($results) {
    foreach ($results as $result) {
        echo $result;
    }
});

$loop->run();

